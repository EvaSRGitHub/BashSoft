﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BashSoft
{
    public static class RepositoryFilters
    {
        public static void FilterAndTake(Dictionary<string, List<int>> wantedData, string wantedFilter, int studentsToFilter)
        {
            if(wantedFilter == "excellent")
            { FilterAndTake(wantedData, x => x >= 5, studentsToFilter);}
            else if(wantedFilter == "average")
            { FilterAndTake(wantedData,x => x>=3.5 && x <5, studentsToFilter); }
            else if(wantedFilter == "poor")
            { FilterAndTake(wantedData, x => x < 3.5, studentsToFilter); }
            else { OutputWriter.DisplayException(ExceptionMessages.InvalidStudentFilter); }
        }

        private static void FilterAndTake(Dictionary<string, List<int>> wantedData, Predicate<double>filterToUse, int studentsToFilter)
        {
            int couterForStudentsToFilter = 0;
            foreach (var studentName_Points in wantedData)
            {
                if(couterForStudentsToFilter == studentsToFilter) { break; }
                double averageScore = studentName_Points.Value.Average();
                double percentageOfFullfilment = (double)averageScore / 100;
                double mark = percentageOfFullfilment * 4 + 2;
                if (filterToUse(mark))
                {
                    OutputWriter.PrintStudent(studentName_Points);
                    couterForStudentsToFilter++;
                }
            }
        }

        

    }
}
