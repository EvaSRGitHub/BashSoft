﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BashSoft
{
    class Launcher
    {
        static void Main(string[] args)
        {

            //IOManager.ChangeCurrentDirAbsolute(@"C:\Windows");
            //IOManager.ChangeCurrentDirRelative("..");
            //IOManager.TraverseDirectory(SessionData.currentPath);

            ////Test is studentsByRepositoryr data quering is working
            //StudentsRepository.InitializeData();
            //StudentsRepository.GetStudentScoresFromCourse("Unity" ,"Ivan");

            //Tester.CompareContent(@"C:\Users\Niki\Desktop\expected.txt", @"C:\Users\Niki\Desktop\actual.txt");

            //IOManager.CreateDirectoryInCurrentFolder("EvaTestBashSoft");

            InputReader.StartReadingCommands();
        }
    }
}
