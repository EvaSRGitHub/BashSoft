﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BashSoft
{
    public static class SessionData
    {

        public static string currentPath = Directory.GetCurrentDirectory();
    }
}
