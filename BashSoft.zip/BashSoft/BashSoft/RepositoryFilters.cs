﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BashSoft
{
    public static class RepositoryFilters
    {
        public static void FilterAndTake(Dictionary<string, List<int>> wantedData, string wantedFilter, int studentsToFilter)
        {
            if(wantedFilter == "excellent")
            { FilterAndTake(wantedData, ExcellentFilter, studentsToFilter);}
            else if(wantedFilter == "average")
            { FilterAndTake(wantedData, AverageFilter, studentsToFilter); }
            else if(wantedFilter == "poor")
            { FilterAndTake(wantedData, PoorFilter, studentsToFilter); }
            else { OutputWriter.DisplayException(ExceptionMessages.InvalidStudentFilter); }
        }

        private static void FilterAndTake(Dictionary<string, List<int>> wantedData, Predicate<double>filterToUse, int studentsToFilter)
        {
            int couterForStudentsToFilter = 0;
            foreach (var studentName_Points in wantedData)
            {
                if(couterForStudentsToFilter == studentsToFilter) { break; }
                double averageMark = AverageMark(studentName_Points.Value);
                if (filterToUse(averageMark))
                {
                    OutputWriter.PrintStudent(studentName_Points);
                    couterForStudentsToFilter++;
                }
            }
        }

        private static bool ExcellentFilter(double mark)
        {
            return mark >= 5.00;
        }

        private static bool AverageFilter(double mark)
        {
            return mark >= 3.50 && mark < 5.00;
        }

        private static bool PoorFilter(double mark)
        {
            return mark < 3.50;
        }

        private static double AverageMark(List<int> scorsOnTasks)
        {
            int totalScore = 0;
            foreach (var score in scorsOnTasks)
            {
                totalScore += score;
            }
            double percentageOfAll = (double) totalScore / (scorsOnTasks.Count * 100);
            double mark = percentageOfAll * 4 + 2;
            return mark;
           
        }


    }
}
