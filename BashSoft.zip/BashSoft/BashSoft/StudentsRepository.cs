﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace BashSoft
{
    public static class StudentsRepository
    {
        public static bool isDataInitialized = false;
        private static Dictionary<string, Dictionary<string, List<int>>> studentsByCourse;

        public static void InitializeData(string fileName)
        {
            if (!isDataInitialized)
            {
                OutputWriter.WriteMessageOnNewLine("Reading data...");
                studentsByCourse = new Dictionary<string, Dictionary<string, List<int>>>();
                ReadData(fileName);
            }
            else { OutputWriter.WriteMessageOnNewLine(ExceptionMessages.DataAlreadyInitialisedException); }
        }

        private static void ReadData(string fileName)
        {
            string path = SessionData.currentPath + "\\" + fileName;

            if (File.Exists(path))
            {
                string pattern = @"^([A-Z][a-zA-Z#\+]*_[A-z]{1}[a-z]{2}_(?:201(?:4|5|6|7)))\s+([A-Z][a-z]{0,3}\d{2}_\d{2,4})\s+(\d{1,2}(?!\d)|100)$";
                Regex reg = new Regex(pattern);
                
                string[] inputLines = File.ReadAllLines(path);

                for (int i = 0; i < inputLines.Length; i++)
                {
                    if (!string.IsNullOrEmpty(inputLines[i]) && reg.IsMatch(inputLines[i]))
                    {
                        Match match = reg.Match(inputLines[i]);
                        string course = match.Groups[1].Value;
                        string student = match.Groups[2].Value;
                        int mark = int.Parse(match.Groups[3].Value);

                        if (!studentsByCourse.ContainsKey(course))
                        { studentsByCourse.Add(course, new Dictionary<string, List<int>>()); }

                        if (!studentsByCourse[course].ContainsKey(student))
                        { studentsByCourse[course].Add(student, new List<int>()); }

                        studentsByCourse[course][student].Add(mark);
                    }
                }
            }
            else { OutputWriter.DisplayException(ExceptionMessages.InvalidPath); }

            isDataInitialized = true;
            OutputWriter.WriteMessageOnNewLine("Data is read!");
        }

        private static bool IsQueryForCoursePossible(string course)
        {
            if (!isDataInitialized)
            {
                OutputWriter.DisplayException(ExceptionMessages.DataNotInitializedExceptionMessage);
            }
            else
            {
                if (studentsByCourse.ContainsKey(course))
                { return true; }
                else
                {
                    OutputWriter.DisplayException(ExceptionMessages.InexistingCourseInDataBase);
                }
            }

            return false;
        }

        private static bool IsQueryForStudenPossible(string course, string student)
        {
            if (IsQueryForCoursePossible(course) && studentsByCourse[course].ContainsKey(student))
            { return true; }
            else { OutputWriter.DisplayException(ExceptionMessages.InexistingStudentInDataBase); }
            return false;
        }

        public static void GetStudentScoresFromCourse(string courseName, string studentName)
        {
            if (IsQueryForStudenPossible(courseName, studentName))
            { OutputWriter.PrintStudent(new KeyValuePair<string, List<int>>(studentName, studentsByCourse[courseName][studentName])); }
        }

        public static void GetAllStudentsFromCours(string courseName)
        {
            if (IsQueryForCoursePossible(courseName))
            {
                OutputWriter.WriteMessageOnNewLine($"{courseName}:");
                foreach (var studednt in studentsByCourse[courseName])
                {
                    OutputWriter.PrintStudent(studednt);
                }
            }
        }

        public static void FilterAndTake(string courseName, string givenFilter, int? studentsToFilter = null)
        {
            if(IsQueryForCoursePossible(courseName))
            {
                if (studentsToFilter == null) { studentsToFilter = studentsByCourse[courseName].Count; }
                RepositoryFilters.FilterAndTake(studentsByCourse[courseName], givenFilter, studentsToFilter.Value);
            }
        }

        public static void OrderAndTake(string courseName, string comparison, int? studentsToOrder = null)
        {
            if (IsQueryForCoursePossible(courseName))
            {
                if(studentsToOrder == null) { studentsToOrder = studentsByCourse[courseName].Count; }
                RepositorySorters.OrderAndTake(studentsByCourse[courseName], comparison, studentsToOrder.Value);
            }
        }
    }
}
