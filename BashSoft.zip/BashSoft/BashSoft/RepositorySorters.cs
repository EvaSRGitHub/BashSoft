﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BashSoft
{
    public static class RepositorySorters
    {
        public static void OrderAndTake(Dictionary<string, List<int>> wantedData, string comparison, int studentsToOrder)
        {
            comparison = comparison.ToLower();
            if(comparison == "ascending") { OrderAndTake(wantedData, studentsToOrder, CompareInAscendingOrder); }
            else if(comparison == "descending") { OrderAndTake(wantedData, studentsToOrder, CompareInDescendingOrder); }
            else { OutputWriter.DisplayException(ExceptionMessages.InvalidComparisonQuery); }
        }

        private static void OrderAndTake(Dictionary<string, List<int>> wantedData, int studentsToOrder, Func<KeyValuePair<string, List<int>>, KeyValuePair<string, List<int>>, int> comparisonFunc)//bubble sort
        {
            int studentsToOrderCount = 0;
            Dictionary<string, List<int>> sortedStudents = new Dictionary<string, List<int>>();
            KeyValuePair<string, List<int>> nextInOrder = new KeyValuePair<string, List<int>>();
            bool isSorted = false;

            while (studentsToOrderCount < studentsToOrder)
            {
                isSorted = true;
                foreach (var studentsWithScore in wantedData)
                {
                    if(!String.IsNullOrEmpty(nextInOrder.Key))
                    {
                        int comparisonResult = comparisonFunc(studentsWithScore, nextInOrder);
                        if(comparisonResult >= 0 && !sortedStudents.ContainsKey(studentsWithScore.Key))
                        {
                            nextInOrder = studentsWithScore;
                            isSorted = false;
                        }

                    }
                    else
                    {
                        if(!sortedStudents.ContainsKey(studentsWithScore.Key))
                        {
                            nextInOrder = studentsWithScore;
                            isSorted = false;
                        }
                    }
                }
                if(!isSorted)
                {
                    sortedStudents.Add(nextInOrder.Key, nextInOrder.Value);
                    OutputWriter.PrintStudent(nextInOrder);
                    studentsToOrderCount++;
                    nextInOrder = new KeyValuePair<string, List<int>>();
                }
            }
            
            //return sortedStudents;

        }

        private static int CompareInAscendingOrder(KeyValuePair<string, List<int>> firstValue, KeyValuePair<string, List<int>> secondValue)
        {
            int totalOfFirstMarks = 0;
            foreach (var mark in firstValue.Value)
            {
                totalOfFirstMarks += mark;
            }

            int totalOfSecondMarks = 0;
            foreach (var mark in secondValue.Value)
            {
                totalOfSecondMarks += mark;
            }
            return totalOfSecondMarks.CompareTo(totalOfFirstMarks);
        }

        private static int CompareInDescendingOrder(KeyValuePair<string, List<int>> firstValue, KeyValuePair<string, List<int>> secondValue)
        {
            int totalOfFirstMarks = 0;
            foreach (var mark in firstValue.Value)
            {
                totalOfFirstMarks += mark;
            }

            int totalOfSecondMarks = 0;
            foreach (var mark in secondValue.Value)
            {
                totalOfSecondMarks += mark;
            }
            return totalOfFirstMarks.CompareTo(totalOfSecondMarks);
        }
    }
}
