﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SimpleJudge
{
    class simpleJudge
    {
        static void Main(string[] args)
        {
            Tester.CompareContent(@"C:\Users\Niki\Desktop\test2.txt", @"C:\Users\Niki\Desktop\test3.txt");
        }
    }
}
