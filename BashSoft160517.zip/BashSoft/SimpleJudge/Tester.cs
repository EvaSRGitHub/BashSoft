﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BashSoft;
using System.IO;

namespace SimpleJudge
{
    class Tester
    {
        public static void CompareContent(string userOutputPath, string expectedOutputPath)
        {
            OutputWriter.WriteMessageOnNewLine("Reading files...");
            string mismatchPath = GetMismatchPath(expectedOutputPath);

            string[] actualOutputLines = File.ReadAllLines(userOutputPath);
            string[] expectedOUtputLines = File.ReadAllLines(expectedOutputPath);

        }

        private static string GetMismatchPath(string expectedOutputPath)
        {
            int indexOf = expectedOutputPath.LastIndexOf('\\');
            string dirPath = expectedOutputPath.Substring(0, indexOf);
            string finalPath = dirPath + @"\Mismatches.txt";
            return finalPath;
        }
    }
}
